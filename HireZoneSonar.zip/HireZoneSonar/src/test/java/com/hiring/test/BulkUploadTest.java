package com.hiring.test;

import java.io.IOException;

import org.junit.Test;

public class BulkUploadTest {

	@Test
	public void test() throws IOException {
		//CandidateDao cust=new CandidateDao();
		//ReadExcelDemo readexcel = new ReadExcelDemo();
//		JSONObject json =new JSONObject();
	//	File file = new File("D:/New folder/CandidateDetails.xlsx");
		//MultipartFile file2 = file.
		//HSSFWorkbook wb  = new HSSFWorkbook(file.);

//		String encodedString = Base64.getEncoder().encodeToString(fileContent);
//		json.put("candidateupload", encodedString);
//		readexcel.read(json);
	//	System.out.println(cust.insertapplicant(custs));
	//	System.out.println(cust.updatecandidate(custs));
	}

}
