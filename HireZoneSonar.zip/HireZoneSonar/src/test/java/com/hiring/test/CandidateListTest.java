package com.hiring.test;

import org.junit.Test;

import com.hiring.dao.CandidateDao;

public class CandidateListTest {

	@Test
	public void test() {
		
		CandidateDao dao = new CandidateDao();
		System.out.println(dao.nameById("21"));
		
		System.out.println(dao.profileList("Java Developer"));
		
	//	System.out.println(dao.candidateMap("51"));

}
}