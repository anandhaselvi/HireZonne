package com.hiring.test;

import org.json.JSONObject;
import org.junit.Test;

import com.hiring.dao.JobDao;

public class MappingTest {

	@Test
	public void test() {

		
		JobDao job = new JobDao();
		JSONObject json = new JSONObject();
		json.put("candidateId", "22");
		json.put("jobpostingId", "20");
		json.put("submittedto", "73");
		json.put("vendorId", "73");
		json.put("customerId", "2");
		json.put("createdby", "22");
		System.out.println(job.candidateMapping(json));
		
		
	
	
	}

}
