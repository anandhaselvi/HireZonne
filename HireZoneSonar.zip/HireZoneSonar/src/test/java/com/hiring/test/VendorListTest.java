package com.hiring.test;

import org.junit.Test;

import com.hiring.dao.VendorDao;

public class VendorListTest {

	@Test
	public void test() {
		VendorDao dao = new VendorDao();
		System.out.println(dao.vendorList("70", "vendor"));
		System.out.println(dao.checkStatus("unapproved", "70"));
		System.out.println(dao.getCustomer());
		System.out.println(dao.fetchvendor("2"));
		System.out.println(dao.getCustomerId("70"));
		System.out.println(dao.getReporting());
		System.out.println(dao.getReportingto("0"));
		System.out.println(dao.getVendor(1));
	
	
	}

}
